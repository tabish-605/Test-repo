# Observa-Lite

Light-weight e-commerce demo with full AWS-native observability (X-Ray, CloudWatch, Prometheus) plus built-in Locust load-gen.

```bash
git clone <repo>
cd observa-lite
docker compose up --build
```

Open http://localhost and start clicking – traces appear in X-Ray within seconds.
