
# E-Commerce OTel Demo

Run locally:

```bash
docker compose up --build
```

Visit `http://localhost:3000` for the store, `http://localhost:16686` for Jaeger, `http://localhost:9090` for Prometheus, `http://localhost:3001` for Grafana.
